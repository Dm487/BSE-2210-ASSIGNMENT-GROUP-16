export default {
  schema: "src/prisma/schema.prisma",
};
